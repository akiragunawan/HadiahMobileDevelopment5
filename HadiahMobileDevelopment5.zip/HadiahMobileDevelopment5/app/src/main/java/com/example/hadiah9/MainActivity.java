package com.example.hadiah9;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle; import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText edtPanjang, edtLebar;
    private TextView txtLuas;
    private Button btnHitung;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setTitle("Hitung Volume Kerucut");

        edtPanjang = (EditText) findViewById(R.id.jari);
        edtLebar = (EditText) findViewById(R.id.tinggi);
        btnHitung = (Button) findViewById(R.id.hitung);
        txtLuas = (TextView) findViewById(R.id.Volume);

        btnHitung.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String jari = edtPanjang.getText().toString().trim();
                String tinggi = edtLebar.getText().toString().trim();

                double Jari = Double.parseDouble(jari);
                double Tinggi = Double.parseDouble(tinggi);


                double volume = 3.14*Jari*Jari*Tinggi/3;
                txtLuas.setText("Volume = " + volume);
            }
        });


    } }
